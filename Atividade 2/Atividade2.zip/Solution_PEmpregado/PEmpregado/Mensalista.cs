﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEmpregado
{
    internal class Mensalista : Empregado
    {
        public Double SalarioMensal {  get; set; }

        //sobrescrevendo o metodo
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é classe Mensalista");
        }

        public Mensalista(int matx, string nomex, 
            DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
    }
}
